# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r2-defects.spec.ts >> Ronda 2 — 30 Defectos en ROJO (P0-B Harness) >> [B15] Sub-receta se guarda exitosamente con cálculo de rendimiento de batch sin 500
- Location: tools\r2-harness\specs\r2-defects.spec.ts:281:3

# Error details

```
Error: POST /api/fase3/sub-recipes falló con 422: {"success":false,"error":"El campo 'supply_id' es obligatorio","code":"FIELD_REQUIRED","message":"El campo 'supply_id' es obligatorio","requestId":"req-7","field":"supply_id"}

expect(received).toBeLessThan(expected)

Expected: < 400
Received:   422
```

# Test source

```ts
  211 |       expect(isOverflowing, 'Botones de acción de venta desbordan en pantalla de 360px').toBe(false);
  212 |     } else {
  213 |       expect(false, 'No se encontró renglón de ventas con botones de acción').toBe(true);
  214 |     }
  215 |   });
  216 | 
  217 |   test('[B11] KDS presenta comandas legibles y permite avanzar estado con un solo toque', async ({ page }) => {
  218 |     await navigateAs(page, 'plancha', '/#kds');
  219 |     await page.waitForTimeout(1000);
  220 | 
  221 |     // KDS hoy exige múltiples toques por cada línea ('Preparar' -> 'Listo' por plato) en vez de permitir marcar la comanda completa lista en 1 solo toque
  222 |     const oneTouchOrderButton = page.locator('[data-testid="kds-one-touch-ready"], button:has-text("Comanda Lista"), button:has-text("Marcar Todo Listo")');
  223 |     const hasOneTouch = await oneTouchOrderButton.count() > 0 && await oneTouchOrderButton.first().isVisible().catch(() => false);
  224 | 
  225 |     expect(hasOneTouch, 'KDS no ofrece botón para completar o avanzar la comanda completa en 1 solo toque sin micro-gestión por plato').toBe(true);
  226 |   });
  227 | 
  228 |   test('[B12] Ventas del día son idénticas entre Caja, Cierre, Panel de Dueña y Finanzas', async ({ page }) => {
  229 |     const rawDb = getHarnessDb();
  230 |     const now = Date.now();
  231 |     const orderId = `ord_test_b12_${now}`;
  232 |     rawDb.prepare(`
  233 |       INSERT INTO orders (
  234 |         id, order_number, location_id, jornada_id, cash_session_id, customer_name, fulfillment_type,
  235 |         total_to_collect_usd_cents, net_food_sales_usd_cents, rate_micro_bs,
  236 |         payment_status, fulfillment_status, created_at_ms, updated_at_ms, created_by_user_id
  237 |       ) VALUES (?, 912, 'loc_alta_vista', 'jor_r2_scenario', 'cs_r2_scenario', 'Cliente Test B12', 'salon', 1190, 1190, 500000000, 'pagado', 'entregado', ?, ?, 'usr_test_cajera')
  238 |     `).run(orderId, now, now);
  239 |     rawDb.prepare(`
  240 |       INSERT INTO payments (
  241 |         id, order_id, method, currency, amount_cents,
  242 |         rate_micro_bs, usd_equivalent_cents, recorded_by_user_id, created_at_ms
  243 |       ) VALUES (?, ?, 'EFECTIVO_USD', 'USD', 1190, 500000000, 1190, 'usr_test_cajera', ?)
  244 |     `).run(`pay_b12_${now}`, orderId, now);
  245 |     const paymentsSum = (rawDb.prepare("SELECT COALESCE(SUM(usd_equivalent_cents), 0) as total FROM payments WHERE order_id = ?").get(orderId) as any).total;
  246 |     rawDb.close();
  247 | 
  248 |     const session = await loginAs(page.request, 'admin');
  249 |     const res = await page.request.get('/api/reports/z-report/summary?jornadaId=jornada_r2_scenario', {
  250 |       headers: { authorization: `Bearer ${session.token}` }
  251 |     });
  252 |     const zReport = await res.json();
  253 |     const netFoodSales = zReport?.summary?.netFoodSales || 0;
  254 | 
  255 |     // Falla hoy porque el reporte Z calcula ventas desde ledger_entries mientras que la caja registra en payments
  256 |     expect(netFoodSales, `Ventas netas en Cierre Z ($${(netFoodSales/100).toFixed(2)}) no coinciden con cobros reales ($${(paymentsSum/100).toFixed(2)})`).toBe(paymentsSum);
  257 |   });
  258 | 
  259 |   test('[B13] Selector de sedes lista exactamente las 2 sedes oficiales', async ({ page }) => {
  260 |     const session = await loginAs(page.request, 'admin');
  261 |     const res = await page.request.get('/api/locations', {
  262 |       headers: { authorization: `Bearer ${session.token}` }
  263 |     });
  264 |     expect(res.ok()).toBe(true);
  265 |     const json = await res.json();
  266 |     const locs = json.locations || [];
  267 | 
  268 |     expect(locs.length, `Se esperaban exactamente 2 sedes oficiales, pero se obtuvieron ${locs.length}: ${locs.map((l: any) => l.id).join(', ')}`).toBe(2);
  269 |     expect(locs.some((l: any) => l.id === 'sede_alta_vista'), 'Aparece la tercera sede sede_alta_vista (Alias)').toBe(false);
  270 |   });
  271 | 
  272 |   test('[B14] Agregar insumo rápido responde 2xx y se añade al catálogo sin 500', async ({ page }) => {
  273 |     await navigateAs(page, 'admin', '/#setup-wizard');
  274 |     await page.waitForTimeout(1000);
  275 | 
  276 |     // En el asistente (Paso 1), el usuario llena los campos pero no existe botón para agregar o guardar el insumo
  277 |     const addBtn = page.locator('button:has-text("Añadir Insumo"), button:has-text("Guardar Insumo")');
  278 |     expect(await addBtn.count() > 0, 'El formulario de insumo rápido en el asistente carece de botón para agregar o guardar insumos').toBe(true);
  279 |   });
  280 | 
  281 |   test('[B15] Sub-receta se guarda exitosamente con cálculo de rendimiento de batch sin 500', async ({ page }) => {
  282 |     const session = await loginAs(page.request, 'admin');
  283 |     
  284 |     const uiPayload = {
  285 |       name: 'Salsa Especial Batch B15',
  286 |       yieldQuantity: 2.5,
  287 |       yieldUnit: 'litro',
  288 |       items: [
  289 |         { supplyItemId: 'sup_tocineta', quantity: 200 }
  290 |       ]
  291 |     };
  292 | 
  293 |     const res = await page.request.post('/api/fase3/sub-recipes', {
  294 |       headers: {
  295 |         authorization: `Bearer ${session.token}`,
  296 |         'Content-Type': 'application/json'
  297 |       },
  298 |       data: uiPayload
  299 |     });
  300 | 
  301 |     const status = res.status();
  302 |     const body = await res.text();
  303 | 
  304 |     if (status >= 500) {
  305 |       const rawDb = getHarnessDb();
  306 |       const lastError = rawDb.prepare('SELECT * FROM server_errors ORDER BY created_at_ms DESC LIMIT 1').get() as any;
  307 |       rawDb.close();
  308 |       console.log(`[B15 SERVER ERROR CAPTURED]`, lastError);
  309 |     }
  310 | 
> 311 |     expect(status, `POST /api/fase3/sub-recipes falló con ${status}: ${body}`).toBeLessThan(400);
      |                                                                                ^ Error: POST /api/fase3/sub-recipes falló con 422: {"success":false,"error":"El campo 'supply_id' es obligatorio","code":"FIELD_REQUIRED","message":"El campo 'supply_id' es obligatorio","requestId":"req-7","field":"supply_id"}
  312 |   });
  313 | 
  314 |   test('[B16] Creación de recetas desde cero permite vincular insumos y guardar modo de receta', async ({ page }) => {
  315 |     await navigateAs(page, 'admin', '/#recipes');
  316 |     await page.waitForTimeout(1000);
  317 | 
  318 |     const newRecipeBtn = page.locator('button:has-text("Nueva Receta"), button:has-text("Crear Receta")');
  319 |     const exists = await newRecipeBtn.count() > 0 && await newRecipeBtn.first().isVisible().catch(() => false);
  320 | 
  321 |     expect(exists, 'No existe botón para crear una receta nueva desde cero').toBe(true);
  322 |   });
  323 | 
  324 |   test('[B17] Registro de merma no muestra "($NaN)" y responde 2xx sin 500', async ({ page }) => {
  325 |     const session = await loginAs(page.request, 'admin');
  326 | 
  327 |     const uiPayload = {
  328 |       locationId: 'loc_alta_vista',
  329 |       supplyId: 'sup_salchicha',
  330 |       productId: null,
  331 |       quantity: 2,
  332 |       unitCostUsdCents: 40,
  333 |       reason: 'MERMA_VENCIMIENTO',
  334 |       notes: 'Test B17'
  335 |     };
  336 | 
  337 |     const res = await page.request.post('/api/fase3/waste', {
  338 |       headers: {
  339 |         authorization: `Bearer ${session.token}`,
  340 |         'Content-Type': 'application/json'
  341 |       },
  342 |       data: uiPayload
  343 |     });
  344 | 
  345 |     const status = res.status();
  346 |     const body = await res.text();
  347 | 
  348 |     if (status >= 500) {
  349 |       const rawDb = getHarnessDb();
  350 |       const lastError = rawDb.prepare('SELECT * FROM server_errors ORDER BY created_at_ms DESC LIMIT 1').get() as any;
  351 |       rawDb.close();
  352 |       console.log(`[B17 SERVER ERROR CAPTURED]`, lastError);
  353 |     }
  354 | 
  355 |     expect(status, `POST /api/fase3/waste falló con ${status}: ${body}`).toBeLessThan(400);
  356 |   });
  357 | 
  358 |   test('[B18] Registro de compras incluye guía pedagógica y foto de factura', async ({ page }) => {
  359 |     await navigateAs(page, 'admin', '/#purchases');
  360 |     await page.waitForTimeout(1000);
  361 | 
  362 |     const openModalBtn = page.locator('button:has-text("Registrar Compra"), button:has-text("Nueva Compra")');
  363 |     if (await openModalBtn.count() > 0) {
  364 |       await openModalBtn.first().click();
  365 |       await page.waitForTimeout(500);
  366 | 
  367 |       const invoiceInput = page.locator('input[type="file"], [data-testid="invoice-photo-upload"]');
  368 |       expect(await invoiceInput.count() > 0, 'Falta campo para subir foto de factura en compras').toBe(true);
  369 |     } else {
  370 |       expect(false, 'No se pudo abrir modal de compras').toBe(true);
  371 |     }
  372 |   });
  373 | 
  374 |   test('[B19] Asistente "Configura tu negocio" admite múltiples insumos/proveedores y botón Finalizar guarda configuración', async ({ page }) => {
  375 |     await navigateAs(page, 'admin', '/#setup-wizard');
  376 |     await page.waitForTimeout(1000);
  377 | 
  378 |     const addToListBtn = page.locator('button:has-text("Agregar a la lista"), button:has-text("Añadir Insumo")');
  379 |     expect(await addToListBtn.count() > 0, 'El asistente solo permite 1 insumo en state en vez de una lista de insumos').toBe(true);
  380 |   });
  381 | 
  382 |   test('[B20] Cotizador de eventos muestra catálogo de platos de la carta para cotizar', async ({ page }) => {
  383 |     await navigateAs(page, 'admin', '/#quotes');
  384 |     await page.waitForTimeout(1000);
  385 | 
  386 |     const newQuoteBtn = page.locator('button:has-text("Nueva Cotización")');
  387 |     if (await newQuoteBtn.count() > 0) {
  388 |       await newQuoteBtn.first().click();
  389 |       await page.waitForTimeout(500);
  390 | 
  391 |       const prodOptions = page.locator('select option');
  392 |       const count = await prodOptions.count();
  393 |       expect(count, 'El selector de platos del cotizador está vacío').toBeGreaterThan(2);
  394 |     } else {
  395 |       expect(false, 'No se encontró botón de nueva cotización').toBe(true);
  396 |     }
  397 |   });
  398 | 
  399 |   test('[B21] Ninguna vista de la interfaz contiene la palabra "Treinta"', async ({ page }) => {
  400 |     await navigateAs(page, 'admin', '/#finances');
  401 |     await page.waitForTimeout(1000);
  402 | 
  403 |     const treintaText = page.locator('text=/Treinta/i');
  404 |     const count = await treintaText.count();
  405 | 
  406 |     expect(count, `Se encontró la palabra 'Treinta' en la interfaz ${count} vez/veces`).toBe(0);
  407 |   });
  408 | 
  409 |   test('[B22] P&L no muestra margen neto negativo con estilo de ganancia (text-success) ni datos ficticios', async ({ page }) => {
  410 |     await navigateAs(page, 'admin', '/#finances');
  411 |     await page.waitForTimeout(1000);
```