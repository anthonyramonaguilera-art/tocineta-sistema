# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r2-defects.spec.ts >> Ronda 2 — 30 Defectos en ROJO (P0-B Harness) >> [B29] Registro de merma no genera fila duplicada en operating_expenses
- Location: tools\r2-harness\specs\r2-defects.spec.ts:544:3

# Error details

```
Error: La merma se duplicó como gasto operativo en operating_expenses

expect(received).toBe(expected) // Object.is equality

Expected: 26
Received: 27
```

# Test source

```ts
  462 | 
  463 |     rawDb.prepare(`
  464 |       INSERT OR REPLACE INTO inventory_movements (
  465 |         id, location_id, supply_id, movement_type, quantity_delta,
  466 |         unit_cost_usd_cents, total_cost_usd_cents, reference_doc, notes, created_by, created_at_ms
  467 |       ) VALUES
  468 |         ('mov_test_ord_1', 'loc_alta_vista', 'sup_salchicha', 'VENTA_PLATO', -1, 40, 40, 'ORD-1', 'Consumo Orden #1', 'usr_test_cajera', ?),
  469 |         ('mov_test_ord_10', 'loc_alta_vista', 'sup_salchicha', 'VENTA_PLATO', -2, 40, 80, 'ORD-10', 'Consumo Orden #10', 'usr_test_cajera', ?),
  470 |         ('mov_test_ord_11', 'loc_alta_vista', 'sup_salchicha', 'VENTA_PLATO', -3, 40, 120, 'ORD-11', 'Consumo Orden #11', 'usr_test_cajera', ?)
  471 |     `).run(now, now, now);
  472 | 
  473 |     const orderNum = 1;
  474 |     const matched = rawDb.prepare(`
  475 |       SELECT reference_doc FROM inventory_movements
  476 |       WHERE (reference_doc LIKE ? OR notes LIKE ?) AND quantity_delta < 0
  477 |     `).all(`%${orderNum}%`, `%${orderNum}%`) as any[];
  478 | 
  479 |     rawDb.close();
  480 | 
  481 |     expect(matched.length, `La anulación por LIKE '%1%' coincidió indebidamente con: ${matched.map(m => m.reference_doc).join(', ')}`).toBe(1);
  482 |   });
  483 | 
  484 |   test('[B25] Botón "Siguiente" en asistentes no se deshabilita sin validación visible y contenido no queda tapado por el pie', async ({ page }) => {
  485 |     await navigateAs(page, 'admin', '/#setup-wizard');
  486 |     await page.waitForTimeout(1000);
  487 | 
  488 |     const nextBtn = page.locator('button:has-text("Siguiente")');
  489 |     await expect(nextBtn.first()).toBeVisible();
  490 | 
  491 |     const hasOverlap = await page.evaluate(() => {
  492 |       const footer = document.querySelector('.border-t');
  493 |       return footer ? window.getComputedStyle(footer).position === 'fixed' : false;
  494 |     });
  495 | 
  496 |     expect(hasOverlap, 'Pie fijo solapa contenido sin espacio inferior').toBe(false);
  497 |   });
  498 | 
  499 |   test('[B26] Ningún botón, pestaña ni título contiene emojis crudos', async ({ page }) => {
  500 |     await navigateAs(page, 'admin', '/#staff');
  501 |     await page.waitForTimeout(1000);
  502 | 
  503 |     const emojiRegex = /\p{Extended_Pictographic}/u;
  504 |     const bodyText = await page.evaluate(() => document.body.innerText || '');
  505 |     const foundEmojis = bodyText.split('\n').filter((line) => emojiRegex.test(line));
  506 | 
  507 |     expect(foundEmojis, `Se encontraron emojis crudos en la interfaz visible: ${foundEmojis.join(' | ')}`).toEqual([]);
  508 |   });
  509 | 
  510 |   test('[B27] Insumo con stock negativo muestra alerta visual prominente en inventario', async ({ page }) => {
  511 |     const rawDb = getHarnessDb();
  512 |     rawDb.prepare("UPDATE location_inventory SET current_stock_qty = -4 WHERE supply_id = 'sup_salchicha' AND location_id = 'loc_alta_vista'").run();
  513 |     rawDb.close();
  514 | 
  515 |     await navigateAs(page, 'admin', '/#inventory');
  516 |     await page.waitForTimeout(1000);
  517 | 
  518 |     const alertBadge = page.locator('.badge-danger:has-text("-4"), [data-testid="negative-stock-alert"]');
  519 |     const isVisible = await alertBadge.count() > 0 && await alertBadge.first().isVisible().catch(() => false);
  520 | 
  521 |     expect(isVisible, 'Falta alerta visual destacada para stock negativo (−4)').toBe(true);
  522 |   });
  523 | 
  524 |   test('[B28] Base de datos y servidor imponen exactamente una jornada diaria abierta global', async () => {
  525 |     const rawDb = getHarnessDb();
  526 |     const now = Date.now();
  527 |     const uniqueId = `jor_duplicate_test_${now}_${Math.random().toString(36).slice(2, 7)}`;
  528 | 
  529 |     let threw = false;
  530 |     try {
  531 |       rawDb.prepare(`
  532 |         INSERT INTO jornadas (id, opened_by_user_id, opened_at_ms, status, location_id)
  533 |         VALUES (?, 'usr_test_admin', ?, 'abierta', 'loc_los_olivos')
  534 |       `).run(uniqueId, now);
  535 |     } catch {
  536 |       threw = true;
  537 |     } finally {
  538 |       rawDb.close();
  539 |     }
  540 | 
  541 |     expect(threw, 'El esquema permite múltiples jornadas abiertas simultáneamente').toBe(true);
  542 |   });
  543 | 
  544 |   test('[B29] Registro de merma no genera fila duplicada en operating_expenses', async () => {
  545 |     const rawDb = getHarnessDb();
  546 |     const countBefore = (rawDb.prepare("SELECT COUNT(*) as cnt FROM operating_expenses WHERE category = 'MERMAS_DESPERDICIOS'").get() as any).cnt;
  547 | 
  548 |     const now = Date.now();
  549 |     const currentJornada = rawDb.prepare("SELECT id FROM jornadas WHERE status = 'abierta' LIMIT 1").get() as any;
  550 | 
  551 |     if (currentJornada) {
  552 |       rawDb.prepare(`
  553 |         INSERT INTO operating_expenses (
  554 |           id, location_id, jornada_id, category, amount_usd_cents, amount_bs_cents, description, authorized_by_user_id, created_at_ms
  555 |         ) VALUES (?, 'loc_alta_vista', ?, 'MERMAS_DESPERDICIOS', 40, 0, 'Merma duplicada test', 'usr_test_admin', ?)
  556 |       `).run(`exp_test_${now}`, currentJornada.id, now);
  557 |     }
  558 | 
  559 |     const countAfter = (rawDb.prepare("SELECT COUNT(*) as cnt FROM operating_expenses WHERE category = 'MERMAS_DESPERDICIOS'").get() as any).cnt;
  560 |     rawDb.close();
  561 | 
> 562 |     expect(countAfter, 'La merma se duplicó como gasto operativo en operating_expenses').toBe(countBefore);
      |                                                                                          ^ Error: La merma se duplicó como gasto operativo en operating_expenses
  563 |   });
  564 | 
  565 |   test('[B30] MenuAdminView.tsx respeta el límite estricto de gobernanza de 400 líneas', () => {
  566 |     const filePath = path.resolve(process.cwd(), 'apps/web/src/components/MenuAdminView.tsx');
  567 |     expect(fs.existsSync(filePath), 'MenuAdminView.tsx debe existir').toBe(true);
  568 |     const content = fs.readFileSync(filePath, 'utf-8');
  569 |     const lineCount = content.split('\n').length;
  570 | 
  571 |     expect(lineCount, `MenuAdminView.tsx tiene ${lineCount} líneas, superando el límite estricto de 400 líneas`).toBeLessThanOrEqual(400);
  572 |   });
  573 | 
  574 | });
  575 | 
```