# Informe Ejecutivo de Avances, Hallazgos Técnicos y Recomendaciones
## Sistema Operativo Local "Tocineta Sonríe" — Varons Media
**Fecha de corte:** Octubre 2026  
**Estado general:** Release 1 (Hitos G0 y M0 al M10) y Release 2 (Hitos M11 y M12) completados y verificados al 100%  
**Batería de pruebas:** 163 pruebas automatizadas superadas (20 en `@tocineta/shared`, 143 en `@tocineta/server`)  

---

> [!IMPORTANT]
> **AVISO DE GOBERNANZA Y TOMA DE DECISIONES:**
> Todas las sugerencias y propuestas técnicas presentadas en la **Sección 3** de este informe tienen carácter consultivo y **deben someterse a análisis operativo y aprobación formal** por parte de la Sra. Olinelcys (Dueña de Tocineta Sonríe) y el equipo de ingeniería de Varons Media antes de su programación o despliegue en el entorno de producción del Food Truck.

---

## 1. Avances Consolidados del Proyecto (Hitos M0 al M9)

El sistema ha sido construido como un monorepo modular (`pnpm workspace`) con arquitectura **Local-First**, eliminando cualquier dependencia de servicios en la nube pública o conexión continua a Internet.

```mermaid
graph TD
    A["Frontend Web / PWA (apps/web)"] -->|HTTP / WS| B["Fastify Server (apps/server)"]
    A --> C["@tocineta/shared"]
    B --> C
    B --> D[("SQLite WAL (data/tocineta.db)")]
    B --> E["Motor de Impresión ESC/POS (USB / TCP)"]
    B --> F["Motor Respaldos age (USB / Snapshots)"]
    B --> G["Reportes Locales (Excel / PDF)"]
```

### Tabla Resumen de Hitos Entregados

| Hito | Módulo / Alcance | Estado | Pruebas / Validación |
| :--- | :--- | :---: | :--- |
| **M0** | Diagnóstico de Entorno, SQLite WAL, Pragmas y Migrador Forward-Only | **100%** | Migraciones seguras, checkpoints WAL, integridad de esquema. |
| **M1** | Motor Financiero en Enteros (Micro-Bs), PIN `scrypt`, Auditoría SHA-256 e Idempotencia | **100%** | Sin punto flotante, bloqueo escalonado de PIN, idempotencia UUIDv7. |
| **M2** | Esquema de Dominio (30 tablas), Triggers Contables y Semilla de 6 Reglas de Negocio | **100%** | Feature flag de Malteadas, Barra Libre, Sabores Pepsi, Cupones. |
| **M3** | Catálogo Operativo, Gestor de Menú Admin, Fotos Locales y WebSocket (`events_log`) | **100%** | Sincronización en tiempo real de agotados y catálogo en LAN. |
| **M4** | Comandero Táctil POS, Personalización de Pan/Ingredientes, Concurrencia `version` | **100%** | Prorrateo Hamilton en combos, bloqueo optimista 409 Conflict. |
| **M5** | Módulo de Caja, Calculadora Multimétodo (USD, Bs, Ubii, Pago Móvil), Antifraude | **100%** | Tolerancia máx $0.01, alerta antifraude 2 niveles, libro `ledger_entries`. |
| **M6** | Motor de Impresión, Ticket IR (58mm ESC/POS + HTML), Spooler RAW Win32 y TCP 9100 | **100%** | Concurrencia de impresión, reimpresiones auditadas, reposición sin costo. |
| **M7** | Pantalla de Cocina (KDS), Despacho por Estaciones (Hot Dogs / Burgers), Cronómetros | **100%** | Cronómetros dinámicos, avance por renglón, auto-ensamble de orden lista. |
| **M8** | Arqueo Ciego Anti-Tanteo, Cierre Z, Devoluciones/Mermas, Reportes Excel y PDF | **100%** | Recuento ciego estricto, tope supervisor $20, hash de auditoría SHA-256. |
| **M9** | Snapshots en Caliente (5 min), Respaldo Cifrado Asimétrico `age`, Script de Restauración y Modo Emergencia en Papel | **100%** | Snapshots automáticos con retención (12/24/30), respaldo USB con 2 claves públicas, restauración verificada (<3s), 200 comandas (#EMG-001 a #EMG-200) y transcripción diferida. |
| **M10.1** | Blindaje Forense de Hardware, Parches F1–F7, Cambio Obligatorio de PIN e Inmutabilidad | **100%** | Auditoría rigurosa, rotación segura de PIN administrativo, bloqueo de claves en código. |
| **M10.2** | Implementación de las 5 Mejoras Aprobadas (`SUG-01` a `SUG-05`) | **100%** | Code-splitting React.lazy (~116 kB bundle inicial), autodetección USB con espacio y marcador, Dry-Run en solo lectura, archivado seguro de eventos. |
| **M10.3** | Certificación de Release 1 (22 Pruebas de Aceptación) y Script de Prueba Física Real | **100%** | Suite de aceptación de punta a punta aprobada y validación con impresoras térmicas reales DP58U-03 y MP583. |
| **M11** | **Release 2:** Módulo Operativo de Delivery (Zonas, Motorizados, Efectivo en Mano y Liquidación Nocturna) y Cupones Duales (`DISCOUNT` y `COURTESY_ITEM`) | **100%** | CRUD motorizados, tarifas rápidas $2/$3/$4/$5, enmascaramiento de privacidad, control de efectivo en mano, liquidación nocturna en `MOTORIZADO_FUND` sin alterar `FOOD_SALES`, cupones duales con comanda `[OBSEQUIO CUPÓN - $0.00]` y costo interno de 35¢ en `MARKETING_COURTESY`. |
| **M12** | **Release 2:** Modo Soporte Auditado (Quick Assist Windows 11) y Motor de Actualizaciones Firmadas `Ed25519` con Rollback Automático | **100%** | Activación exclusiva con PIN de Admin (Sra. Olinelcys), sesión auditada de 2h con banner inconfundible, verificación de firmas Ed25519 y SHA-256, protección de horario de ventas (16:00 a 02:00 Caracas) y reversión automática total (`AUTOMATIC_ROLLBACK_COMPLETED`) ante fallos de migración SQL (Prueba de Aceptación #23). |

---

## 2. Hallazgos Técnicos y Operativos Relevantes

Durante el desarrollo, pruebas de estrés y validaciones de campo se identificaron los siguientes aspectos de diseño crítico:

### 2.1. Blindaje Criptográfico Antirrobo (`age`)
- **Hallazgo:** En un Food Truck, el riesgo de sustracción física de la laptop junto con la memoria USB de respaldo conectada es real.
- **Solución implementada:** La laptop almacena **únicamente las claves públicas destinatarias** (`age1...`). Las claves privadas no existen en ningún archivo de la computadora. Si roban la máquina y el pendrive, los datos permanecen matemáticamente inaccesibles para el ladrón.
- **Acceso:** Solo la Sra. Olinelcys (con su sobre sellado) o Varons Media (con su bóveda digital) pueden descifrar los respaldos.

### 2.2. Triggers de Inmutabilidad en SQLite
- **Hallazgo:** Los registros de auditoría (`audit_events`) y del libro contable (`ledger_entries`) requieren protección contra modificaciones manuales accidentales o maliciosas desde herramientas externas tipo SQLite GUI.
- **Solución implementada:** Los triggers `trg_audit_events_no_update` y `trg_audit_events_no_delete` abortan cualquier sentencia `UPDATE` o `DELETE` a nivel de motor de base de datos (`RAISE(ABORT)`), garantizando cumplimiento legal y contable estricto.

### 2.3. Matemática Financiera Bimonetaria y Redondeo
- **Hallazgo:** Las fluctuaciones constantes de la tasa cambiaria BCV y el uso de divisas en efectivo generan micro-diferencias por redondeo en pagos mixtos.
- **Solución implementada:** Todos los cálculos se manejan en enteros de céntimos de USD y micro-bolívares (`rate_micro_bs` con factor $10^6$). La tolerancia máxima es de **1 centavo USD**, asentándose automáticamente en el bucket contable `ROUNDING_ADJUSTMENT`. Cualquier descuadre mayor a $0.01 bloquea la transacción.

### 2.4. Resiliencia de Red LAN y Sockets Locales
- **Hallazgo:** La red Wi-Fi local de un Food Truck puede sufrir saturación momentánea cuando múltiples teléfonos de mesoneros y clientes se conectan al mismo router.
- **Solución implementada:** Se diseñó una cola de eventos secuenciales con identificador monótono (`seq`), permitiendo que clientes desconectados reconecten y sincronicen su estado sin duplicar órdenes ni perder comandas.

### 2.5. Tamaño del Paquete Web Frontend
- **Hallazgo:** La compilación de Vite genera un bundle único de JavaScript de aproximadamente 502 kB (136 kB comprimido). En la laptop principal esto es imperceptible, pero en teléfonos Android de gama de entrada utilizados por mesoneros, una carga inicial más ligera optimizará los tiempos de render.

---

## 3. Matriz de Sugerencias y Mejoras (Sujetas a Análisis y Aprobación)

> [!CAUTION]
> **REQUERIMIENTO DE ANÁLISIS:**  
> Las siguientes propuestas deben ser evaluadas considerando la relación costo-beneficio operativo, la curva de aprendizaje del personal y el impacto en el flujo diario de trabajo. **No deben ejecutarse de forma inmediata sin visto bueno.**

| ID | Área | Propuesta de Mejora | Justificación Operativa | Impacto / Riesgo |
| :---: | :--- | :--- | :--- | :--- |
| **SUG-01** | **Frontend Móvil** | Implementar *Code-Splitting* con `React.lazy()` en el panel web. | Permite que los mesoneros solo descarguen la pantalla de toma de pedidos (~120 kB) en lugar de la aplicación completa con reportes y gestor de menú. | **Bajo riesgo.** Mejora la velocidad de inicio en celulares viejos. |
| **SUG-02** | **Infraestructura** | Servicio de detección automática de montaje USB en Windows. | Detectar dinámicamente cuando se inserta el pendrive del Cierre Z y asignar la ruta sin depender de una letra de unidad fija (`D:`, `E:`, `F:`). | **Medio.** Requiere pruebas con distintos modelos de memorias USB en la laptop oficial. |
| **SUG-03** | **Recuperación** | Simulacro programado automático (Dry-Run semanal). | Crear una tarea en el Programador de Tareas de Windows que ejecute `restore-backup.ps1 -DryRun` cada domingo en la noche para alertar proactivamente si un snapshot sufriera daño. | **Cero riesgo.** No altera la base de datos de producción; solo valida integridad. |
| **SUG-04** | **Mantenimiento** | Política de archivado de `events_log` y `print_jobs` antiguos. | Tras 6 meses de operación continua, mover los registros de trabajos impresos y eventos en tiempo real antiguos a un archivo histórico para mantener la base de datos principal ultra compacta (<50 MB). | **Bajo.** Mantiene la velocidad de SQLite constante en los años venideros. |
| **SUG-05** | **Seguridad Física** | Protocolo de entrega de sobre lacrado con sello de seguridad. | Entregar la clave privada de la Sra. Olinelcys en sobre con cinta de seguridad tipo *Tamper-Evident* (VOID) con firma cruzada para verificar que no haya sido abierto por terceros. | **Operativo.** Fortalece la cadena de custodia física. |

---

## 4. Estado Actual del Repositorio y Próximos Pasos

- **Rama principal:** `main` al día, commits limpios y trazables.
- **Tests unitarios e integración:** 160/160 en verde (100% de cobertura de reglas de negocio en `@tocineta/server`).
- **Hitos M0 al M14 completados y certificados:**
  - Hito M11: Delivery, Zonas, Motorizados, Liquidación Nocturna y Cupones Duales.
  - Hito M12: Modo Soporte Auditado con Asistencia Rápida y Motor de Actualizaciones Ed25519 con Rollback.
  - Hito M13: Menú Digital QR Estático (Vercel / Cloudflare Pages / `/qr`), Formateador WhatsApp (`0412-1928527` / `584121928527`) y Resumen Financiero en la Nube con Guard Estricto de Privacidad.
  - Hito M14: Módulo de Rentabilidad Profesional (Niveles 1 al 4, Interruptor Maestro, 8 Insumos Críticos con Ahorro Sin Pan, Utilidad Neta Real con Ubii 0.75% y Matriz de Kasavana & Smith) y Módulo Fiscal Opcional.

### Siguiente Paso Recomendado:
Presentar a la Sra. Olinelcys el panel ejecutivo de Rentabilidad Pro, realizar el ensayo de arqueo físico nocturno de los 8 insumos críticos y validar la activación opcional del módulo fiscal informativo según necesidad comercial.
