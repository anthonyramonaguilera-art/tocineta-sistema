# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r2-defects.spec.ts >> Ronda 2 — 30 Defectos en ROJO (P0-B Harness) >> [B17] Registro de merma no muestra "($NaN)" y responde 2xx sin 500
- Location: tools\r2-harness\specs\r2-defects.spec.ts:324:3

# Error details

```
Error: POST /api/fase3/waste falló con 500: {"success":false,"error":"Error interno del servidor","code":"INTERNAL","message":"Error interno del servidor","requestId":"req-5"}

expect(received).toBeLessThan(expected)

Expected: < 400
Received:   500
```

# Test source

```ts
  255 |     // Falla hoy porque el reporte Z calcula ventas desde ledger_entries mientras que la caja registra en payments
  256 |     expect(netFoodSales, `Ventas netas en Cierre Z ($${(netFoodSales/100).toFixed(2)}) no coinciden con cobros reales ($${(paymentsSum/100).toFixed(2)})`).toBe(paymentsSum);
  257 |   });
  258 | 
  259 |   test('[B13] Selector de sedes lista exactamente las 2 sedes oficiales', async ({ page }) => {
  260 |     const session = await loginAs(page.request, 'admin');
  261 |     const res = await page.request.get('/api/locations', {
  262 |       headers: { authorization: `Bearer ${session.token}` }
  263 |     });
  264 |     expect(res.ok()).toBe(true);
  265 |     const json = await res.json();
  266 |     const locs = json.locations || [];
  267 | 
  268 |     expect(locs.length, `Se esperaban exactamente 2 sedes oficiales, pero se obtuvieron ${locs.length}: ${locs.map((l: any) => l.id).join(', ')}`).toBe(2);
  269 |     expect(locs.some((l: any) => l.id === 'sede_alta_vista'), 'Aparece la tercera sede sede_alta_vista (Alias)').toBe(false);
  270 |   });
  271 | 
  272 |   test('[B14] Agregar insumo rápido responde 2xx y se añade al catálogo sin 500', async ({ page }) => {
  273 |     await navigateAs(page, 'admin', '/#setup-wizard');
  274 |     await page.waitForTimeout(1000);
  275 | 
  276 |     // En el asistente (Paso 1), el usuario llena los campos pero no existe botón para agregar o guardar el insumo
  277 |     const addBtn = page.locator('button:has-text("Añadir Insumo"), button:has-text("Guardar Insumo")');
  278 |     expect(await addBtn.count() > 0, 'El formulario de insumo rápido en el asistente carece de botón para agregar o guardar insumos').toBe(true);
  279 |   });
  280 | 
  281 |   test('[B15] Sub-receta se guarda exitosamente con cálculo de rendimiento de batch sin 500', async ({ page }) => {
  282 |     const session = await loginAs(page.request, 'admin');
  283 |     
  284 |     const uiPayload = {
  285 |       name: 'Salsa Especial Batch B15',
  286 |       yieldQuantity: 2.5,
  287 |       yieldUnit: 'litro',
  288 |       items: [
  289 |         { supplyItemId: 'sup_tocineta', quantity: 200 }
  290 |       ]
  291 |     };
  292 | 
  293 |     const res = await page.request.post('/api/fase3/sub-recipes', {
  294 |       headers: {
  295 |         authorization: `Bearer ${session.token}`,
  296 |         'Content-Type': 'application/json'
  297 |       },
  298 |       data: uiPayload
  299 |     });
  300 | 
  301 |     const status = res.status();
  302 |     const body = await res.text();
  303 | 
  304 |     if (status >= 500) {
  305 |       const rawDb = getHarnessDb();
  306 |       const lastError = rawDb.prepare('SELECT * FROM server_errors ORDER BY created_at_ms DESC LIMIT 1').get() as any;
  307 |       rawDb.close();
  308 |       console.log(`[B15 SERVER ERROR CAPTURED]`, lastError);
  309 |     }
  310 | 
  311 |     expect(status, `POST /api/fase3/sub-recipes falló con ${status}: ${body}`).toBeLessThan(400);
  312 |   });
  313 | 
  314 |   test('[B16] Creación de recetas desde cero permite vincular insumos y guardar modo de receta', async ({ page }) => {
  315 |     await navigateAs(page, 'admin', '/#recipes');
  316 |     await page.waitForTimeout(1000);
  317 | 
  318 |     const newRecipeBtn = page.locator('button:has-text("Nueva Receta"), button:has-text("Crear Receta")');
  319 |     const exists = await newRecipeBtn.count() > 0 && await newRecipeBtn.first().isVisible().catch(() => false);
  320 | 
  321 |     expect(exists, 'No existe botón para crear una receta nueva desde cero').toBe(true);
  322 |   });
  323 | 
  324 |   test('[B17] Registro de merma no muestra "($NaN)" y responde 2xx sin 500', async ({ page }) => {
  325 |     const session = await loginAs(page.request, 'admin');
  326 | 
  327 |     const uiPayload = {
  328 |       locationId: 'loc_alta_vista',
  329 |       supplyId: 'sup_salchicha',
  330 |       productId: null,
  331 |       quantity: 2,
  332 |       unitCostUsdCents: 40,
  333 |       reason: 'MERMA_VENCIMIENTO',
  334 |       notes: 'Test B17'
  335 |     };
  336 | 
  337 |     const res = await page.request.post('/api/fase3/waste', {
  338 |       headers: {
  339 |         authorization: `Bearer ${session.token}`,
  340 |         'Content-Type': 'application/json'
  341 |       },
  342 |       data: uiPayload
  343 |     });
  344 | 
  345 |     const status = res.status();
  346 |     const body = await res.text();
  347 | 
  348 |     if (status >= 500) {
  349 |       const rawDb = getHarnessDb();
  350 |       const lastError = rawDb.prepare('SELECT * FROM server_errors ORDER BY created_at_ms DESC LIMIT 1').get() as any;
  351 |       rawDb.close();
  352 |       console.log(`[B17 SERVER ERROR CAPTURED]`, lastError);
  353 |     }
  354 | 
> 355 |     expect(status, `POST /api/fase3/waste falló con ${status}: ${body}`).toBeLessThan(400);
      |                                                                          ^ Error: POST /api/fase3/waste falló con 500: {"success":false,"error":"Error interno del servidor","code":"INTERNAL","message":"Error interno del servidor","requestId":"req-5"}
  356 |   });
  357 | 
  358 |   test('[B18] Registro de compras incluye guía pedagógica y foto de factura', async ({ page }) => {
  359 |     await navigateAs(page, 'admin', '/#purchases');
  360 |     await page.waitForTimeout(1000);
  361 | 
  362 |     const openModalBtn = page.locator('button:has-text("Registrar Compra"), button:has-text("Nueva Compra")');
  363 |     if (await openModalBtn.count() > 0) {
  364 |       await openModalBtn.first().click();
  365 |       await page.waitForTimeout(500);
  366 | 
  367 |       const invoiceInput = page.locator('input[type="file"], [data-testid="invoice-photo-upload"]');
  368 |       expect(await invoiceInput.count() > 0, 'Falta campo para subir foto de factura en compras').toBe(true);
  369 |     } else {
  370 |       expect(false, 'No se pudo abrir modal de compras').toBe(true);
  371 |     }
  372 |   });
  373 | 
  374 |   test('[B19] Asistente "Configura tu negocio" admite múltiples insumos/proveedores y botón Finalizar guarda configuración', async ({ page }) => {
  375 |     await navigateAs(page, 'admin', '/#setup-wizard');
  376 |     await page.waitForTimeout(1000);
  377 | 
  378 |     const addToListBtn = page.locator('button:has-text("Agregar a la lista"), button:has-text("Añadir Insumo")');
  379 |     expect(await addToListBtn.count() > 0, 'El asistente solo permite 1 insumo en state en vez de una lista de insumos').toBe(true);
  380 |   });
  381 | 
  382 |   test('[B20] Cotizador de eventos muestra catálogo de platos de la carta para cotizar', async ({ page }) => {
  383 |     await navigateAs(page, 'admin', '/#quotes');
  384 |     await page.waitForTimeout(1000);
  385 | 
  386 |     const newQuoteBtn = page.locator('button:has-text("Nueva Cotización")');
  387 |     if (await newQuoteBtn.count() > 0) {
  388 |       await newQuoteBtn.first().click();
  389 |       await page.waitForTimeout(500);
  390 | 
  391 |       const prodOptions = page.locator('select option');
  392 |       const count = await prodOptions.count();
  393 |       expect(count, 'El selector de platos del cotizador está vacío').toBeGreaterThan(2);
  394 |     } else {
  395 |       expect(false, 'No se encontró botón de nueva cotización').toBe(true);
  396 |     }
  397 |   });
  398 | 
  399 |   test('[B21] Ninguna vista de la interfaz contiene la palabra "Treinta"', async ({ page }) => {
  400 |     await navigateAs(page, 'admin', '/#finances');
  401 |     await page.waitForTimeout(1000);
  402 | 
  403 |     const treintaText = page.locator('text=/Treinta/i');
  404 |     const count = await treintaText.count();
  405 | 
  406 |     expect(count, `Se encontró la palabra 'Treinta' en la interfaz ${count} vez/veces`).toBe(0);
  407 |   });
  408 | 
  409 |   test('[B22] P&L no muestra margen neto negativo con estilo de ganancia (text-success) ni datos ficticios', async ({ page }) => {
  410 |     await navigateAs(page, 'admin', '/#finances');
  411 |     await page.waitForTimeout(1000);
  412 | 
  413 |     // En ProfitAndLossTab.tsx:31 el margen neto está hardcodeado con clase text-success
  414 |     const greenMargin = page.locator('span.text-success:has-text("Margen Neto")');
  415 |     const count = await greenMargin.count();
  416 |     expect(count, 'El margen neto está fijo con clase text-success (verde) independientemente de la utilidad').toBe(0);
  417 |   });
  418 | 
  419 |   test('[B23] KDS ejecuta audio, navigator.vibrate y clase de destello al recibir nuevo pedido', async ({ page }) => {
  420 |     await page.addInitScript(() => {
  421 |       (window as any).__vibrateCalled = false;
  422 |       navigator.vibrate = () => {
  423 |         (window as any).__vibrateCalled = true;
  424 |         return true;
  425 |       };
  426 |     });
  427 | 
  428 |     await navigateAs(page, 'plancha', '/#kds');
  429 |     await page.waitForTimeout(1000);
  430 | 
  431 |     const rawDb = getHarnessDb();
  432 |     const now = Date.now();
  433 |     const orderId = `ord_test_b23_${now}`;
  434 |     rawDb.prepare(`
  435 |       INSERT INTO orders (
  436 |         id, order_number, location_id, jornada_id, cash_session_id, customer_name, fulfillment_type, table_number,
  437 |         total_to_collect_usd_cents, net_food_sales_usd_cents, rate_micro_bs, payment_status, fulfillment_status,
  438 |         station_status_hot_dogs, created_at_ms, updated_at_ms, created_by_user_id
  439 |       ) VALUES (?, 623, 'loc_alta_vista', 'jor_r2_scenario', 'cs_r2_scenario', 'Cliente Alerta B23', 'para_llevar', 'Mostrador', 500, 500, 500000000, 'pagado', 'en_preparacion', 'pendiente', ?, ?, 'usr_test_cajera')
  440 |     `).run(orderId, now, now);
  441 |     rawDb.prepare(`
  442 |       INSERT INTO order_lines (
  443 |         id, order_id, product_id, quantity, unit_price_usd_cents,
  444 |         prorated_unit_price_usd_cents, subtotal_usd_cents, station, status, created_at_ms
  445 |       ) VALUES (?, ?, 'prod_brazil_dog', 1, 500, 500, 500, 'hot_dogs', 'pendiente', ?)
  446 |     `).run(`line_${orderId}`, orderId, now);
  447 |     rawDb.close();
  448 | 
  449 |     const refreshBtn = page.locator('button:has-text("Actualizar")');
  450 |     if (await refreshBtn.isVisible()) {
  451 |       await refreshBtn.click();
  452 |     }
  453 | 
  454 |     await expect.poll(async () => {
  455 |       return await page.evaluate(() => (window as any).__vibrateCalled);
```